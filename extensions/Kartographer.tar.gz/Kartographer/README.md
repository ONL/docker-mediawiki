Kartographer is a MediaWiki extension that adds map capability
See  https://www.mediawiki.org/wiki/Extension:Kartographer
