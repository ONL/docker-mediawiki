<?php

namespace Kartographer\Tests\Tag;

/**
 * @covers \Kartographer\Tag\MapLink
 *
 * @license MIT
 */
class MapLinkTest extends \PHPUnit\Framework\TestCase {
	use TagHandlerTest;

}
