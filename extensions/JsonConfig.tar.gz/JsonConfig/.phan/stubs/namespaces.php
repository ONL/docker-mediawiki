<?php

/**
 * namespace constant defined in extension.json of JsonConfig extension
 * Can be removed, when JsonConfig get a similar stub to pass phan
 */
define( 'NS_CONFIG', 482 );
define( 'NS_CONFIG_TALK', 483 );
define( 'NS_DATA', 486 );
define( 'NS_DATA_TALK', 487 );
