See https://www.mediawiki.org/wiki/Extension:JsonConfig
