<?php
if ( !defined( 'MEDIAWIKI' ) ) {
	die( -1 );
}

// require_once 'TestAllConfigs.php';
// require_once 'TestNoValidation.php';
// require_once 'TestZeroContent.php';
require_once 'TestObjectContent.php';
