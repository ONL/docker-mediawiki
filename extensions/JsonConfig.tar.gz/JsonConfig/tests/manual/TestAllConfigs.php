<?php
if ( !defined( 'MEDIAWIKI' ) ) {
	die( -1 );
}

$wgJsonConfigs['Test.AllConfigs'] = [
	'model' => null,
	'isLocal' => true,
];

$wgJsonConfigs['Test.AllConfigs'] = [
	'model' => null,
	'isLocal' => true,
	'namespace' => 600, 'nsname' => 'Z'
];
